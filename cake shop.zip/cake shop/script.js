// --- Data (Simulated Backend) ---
const cakes = [
    {
        id: 1,
        name: "Classic Chocolate Truffle",
        description: "Rich, dark chocolate sponge layered with creamy chocolate ganache. A true delight for chocolate lovers.",
        price: 2500,
        imageUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Chocolate"
    },
    {
        id: 2,
        name: "Strawberry Shortcake",
        description: "Light vanilla sponge with fresh strawberries and whipped cream. Perfect for a summer celebration.",
        price: 2800,
        imageUrl: "https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Fruit"
    },
    {
        id: 3,
        name: "Red Velvet Delight",
        description: "Classic red velvet cake with smooth cream cheese frosting. Elegant and delicious.",
        price: 3200,
        imageUrl: "https://images.unsplash.com/photo-1586788680434-30d324b2d46f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Specialty"
    },
    {
        id: 4,
        name: "Mango Mousse Cake",
        description: "Tropical mango mousse layered on a light biscuit base. Refreshing and sweet.",
        price: 3000,
        imageUrl: "https://images.unsplash.com/photo-1542826438-bd32f43d626f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Fruit"
    },
    {
        id: 5,
        name: "Black Forest Gateau",
        description: "Chocolate sponge, cherries, and whipped cream, topped with chocolate shavings.",
        price: 2600,
        imageUrl: "https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Classic"
    },
    {
        id: 6,
        name: "Vanilla Bean Dream",
        description: "Pure vanilla bean infused cake with a rich buttercream frosting.",
        price: 2200,
        imageUrl: "https://images.unsplash.com/photo-1535141192574-5d4897c12636?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Classic"
    },
    {
        id: 7,
        name: "Lemon Raspberry Cake",
        description: "Zesty lemon cake layers filled with tangy raspberry compote.",
        price: 2900,
        imageUrl: "https://images.unsplash.com/photo-1519869325930-281384150729?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Fruit"
    },
    {
        id: 8,
        name: "Coffee Walnut Cake",
        description: "Espresso infused cake with crunchy walnuts and coffee buttercream.",
        price: 2700,
        imageUrl: "https://images.unsplash.com/photo-1621303837174-89787a7d4729?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Specialty"
    },
    {
        id: 9,
        name: "Blueberry Cheesecake",
        description: "Creamy New York style cheesecake topped with sweet blueberry sauce.",
        price: 3500,
        imageUrl: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Cheesecake"
    },
    {
        id: 10,
        name: "Pistachio Rose Cake",
        description: "Delicate rose-flavored cake with crushed pistachios and cream.",
        price: 3400,
        imageUrl: "https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        category: "Specialty"
    }
];

// Initialize Local Storage if empty
if (!localStorage.getItem('orders')) {
    localStorage.setItem('orders', JSON.stringify([]));
}
if (!localStorage.getItem('feedback')) {
    localStorage.setItem('feedback', JSON.stringify([
        { name: "Amali Perera", rating: 5, message: "The chocolate truffle cake was amazing! Highly recommended." },
        { name: "Kasun Silva", rating: 4, message: "Very fresh and tasty. Delivery was on time." }
    ]));
}

// --- DOM Elements ---
const cakeGrid = document.getElementById('cake-grid');
const modal = document.getElementById('order-modal');
const closeBtn = document.querySelector('.close-btn');
const orderForm = document.getElementById('order-form');
const selectedCakeInfo = document.getElementById('selected-cake-info');
const modalTotalPrice = document.getElementById('modal-total-price');
const quantityInput = document.getElementById('quantity');
const feedbackForm = document.getElementById('feedback-form');
const feedbackList = document.getElementById('feedback-list');

const adminLink = document.getElementById('admin-link');
const adminSection = document.getElementById('admin');
const homeSection = document.getElementById('home');
const menuSection = document.getElementById('menu');
const feedbackSec = document.getElementById('feedback');

// --- Render Cakes ---
function renderCakes() {
    cakeGrid.innerHTML = '';
    cakes.forEach(cake => {
        const cakeCard = document.createElement('div');
        cakeCard.className = 'cake-card';
        cakeCard.innerHTML = `
            <img src="${cake.imageUrl}" alt="${cake.name}" class="cake-img">
            <div class="cake-info">
                <span class="cake-category">${cake.category}</span>
                <h3 class="cake-title">${cake.name}</h3>
                <p class="cake-desc">${cake.description}</p>
                <div class="cake-footer">
                    <span class="cake-price">Rs. ${cake.price}</span>
                    <button class="order-btn" onclick="openOrderModal(${cake.id})">Order Now</button>
                </div>
            </div>
        `;
        cakeGrid.appendChild(cakeCard);
    });
}

// --- Order Modal Logic ---
let currentSelectedCake = null;

window.openOrderModal = (cakeId) => {
    currentSelectedCake = cakes.find(c => c.id === cakeId);
    if (!currentSelectedCake) return;

    document.getElementById('cake-id').value = currentSelectedCake.id;
    selectedCakeInfo.innerHTML = `
        <div style="margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
            <h3>Ordering: ${currentSelectedCake.name}</h3>
            <p>Price per item: Rs. ${currentSelectedCake.price}</p>
        </div>
    `;
    
    quantityInput.value = 1;
    updateTotalPrice();
    
    modal.style.display = 'flex';
}

closeBtn.onclick = () => {
    modal.style.display = 'none';
}

window.onclick = (event) => {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

quantityInput.addEventListener('input', updateTotalPrice);

function updateTotalPrice() {
    if (currentSelectedCake) {
        const qty = parseInt(quantityInput.value) || 1;
        modalTotalPrice.textContent = (currentSelectedCake.price * qty).toLocaleString();
    }
}

// --- Submit Order ---
orderForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const qty = parseInt(quantityInput.value) || 1;
    
    const newOrder = {
        id: Date.now(),
        date: new Date().toLocaleString(),
        cakeName: currentSelectedCake.name,
        quantity: qty,
        totalPrice: currentSelectedCake.price * qty,
        customerName: document.getElementById('customer-name').value,
        phone: document.getElementById('customer-phone').value,
        address: document.getElementById('delivery-address').value
    };

    const orders = JSON.parse(localStorage.getItem('orders'));
    orders.push(newOrder);
    localStorage.setItem('orders', JSON.stringify(orders));

    alert('Order placed successfully! We will contact you shortly.');
    modal.style.display = 'none';
    orderForm.reset();
    renderAdminOrders(); // Update admin view if open
});

// --- Feedback Logic ---
function renderFeedback() {
    const feedbacks = JSON.parse(localStorage.getItem('feedback'));
    feedbackList.innerHTML = '';
    
    // Reverse to show newest first, and limit to 5
    feedbacks.reverse().slice(0, 5).forEach(fb => {
        const stars = '⭐'.repeat(fb.rating);
        const card = document.createElement('div');
        card.className = 'feedback-card';
        card.innerHTML = `
            <div class="fb-header">
                <span>${fb.name}</span>
                <span class="fb-rating">${stars}</span>
            </div>
            <p>${fb.message}</p>
        `;
        feedbackList.appendChild(card);
    });
}

feedbackForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const newFb = {
        name: document.getElementById('fb-name').value,
        rating: parseInt(document.getElementById('fb-rating').value),
        message: document.getElementById('fb-message').value
    };

    const feedbacks = JSON.parse(localStorage.getItem('feedback'));
    feedbacks.push(newFb);
    localStorage.setItem('feedback', JSON.stringify(feedbacks));

    alert('Thank you for your feedback!');
    feedbackForm.reset();
    renderFeedback();
});

// --- Admin Logic ---
function renderAdminOrders() {
    const orders = JSON.parse(localStorage.getItem('orders'));
    const ordersList = document.getElementById('orders-list');
    
    if (orders.length === 0) {
        ordersList.innerHTML = '<p>No orders yet.</p>';
        return;
    }

    ordersList.innerHTML = '';
    orders.reverse().forEach(order => {
        const item = document.createElement('div');
        item.className = 'order-item';
        item.innerHTML = `
            <strong>Order #${order.id}</strong> - ${order.date}<br>
            <strong>Customer:</strong> ${order.customerName} (${order.phone})<br>
            <strong>Address:</strong> ${order.address}<br>
            <strong>Item:</strong> ${order.cakeName} x ${order.quantity}<br>
            <strong>Total:</strong> Rs. ${order.totalPrice.toLocaleString()}
        `;
        ordersList.appendChild(item);
    });
}

const aboutSection = document.getElementById('about');
const contactSection = document.getElementById('contact');

adminLink.addEventListener('click', (e) => {
    e.preventDefault();
    homeSection.style.display = 'none';
    aboutSection.style.display = 'none';
    menuSection.style.display = 'none';
    contactSection.style.display = 'none';
    feedbackSec.style.display = 'none';
    adminSection.style.display = 'block';
    renderAdminOrders();
});

document.getElementById('clear-orders').addEventListener('click', () => {
    if(confirm('Are you sure you want to clear all orders?')) {
        localStorage.setItem('orders', JSON.stringify([]));
        renderAdminOrders();
    }
});

// Navigation links to show main content
document.querySelectorAll('.nav-links a:not(#admin-link)').forEach(link => {
    link.addEventListener('click', () => {
        adminSection.style.display = 'none';
        homeSection.style.display = 'flex'; // Hero is flex
        aboutSection.style.display = 'block';
        menuSection.style.display = 'block';
        contactSection.style.display = 'block';
        feedbackSec.style.display = 'grid';
    });
});

// Init
renderCakes();
renderFeedback();
