const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize SQLite Database
const dbPath = path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        
        // Create Tables
        db.serialize(() => {
            // Cakes Table
            db.run(`CREATE TABLE IF NOT EXISTS cakes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                imageUrl TEXT,
                category TEXT
            )`);

            // Orders Table
            db.run(`CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customerName TEXT NOT NULL,
                email TEXT NOT NULL,
                address TEXT NOT NULL,
                phone TEXT NOT NULL,
                cakeId INTEGER,
                quantity INTEGER,
                totalPrice REAL,
                orderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cakeId) REFERENCES cakes (id)
            )`);

            // Feedback Table
            db.run(`CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                rating INTEGER NOT NULL,
                message TEXT NOT NULL,
                date DATETIME DEFAULT CURRENT_TIMESTAMP
            )`);

            // Seed initial data if cakes table is empty
            db.get("SELECT count(*) AS count FROM cakes", (err, row) => {
                if (row && row.count === 0) {
                    console.log("Seeding initial cakes data...");
                    const insertStmt = db.prepare("INSERT INTO cakes (name, description, price, imageUrl, category) VALUES (?, ?, ?, ?, ?)");
                    insertStmt.run("Classic Chocolate Truffle", "Rich, dark chocolate sponge layered with creamy chocolate ganache.", 2500, "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", "Chocolate");
                    insertStmt.run("Strawberry Shortcake", "Light vanilla sponge with fresh strawberries and whipped cream.", 2800, "https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", "Fruit");
                    insertStmt.run("Red Velvet Delight", "Classic red velvet cake with smooth cream cheese frosting.", 3200, "https://images.unsplash.com/photo-1586788680434-30d324b2d46f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", "Specialty");
                    insertStmt.run("Mango Mousse Cake", "Tropical mango mousse layered on a light biscuit base.", 3000, "https://images.unsplash.com/photo-1542826438-bd32f43d626f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80", "Fruit");
                    insertStmt.finalize();
                }
            });
        });
    }
});

// --- API Routes ---

// Get all cakes
app.get('/api/cakes', (req, res) => {
    db.all("SELECT * FROM cakes", [], (err, rows) => {
        if (err) {
            res.status(400).json({ error: err.message });
            return;
        }
        res.json({
            message: "success",
            data: rows
        });
    });
});

// Place a new order
app.post('/api/orders', (req, res) => {
    const { customerName, email, address, phone, cakeId, quantity, totalPrice } = req.body;
    
    // Basic validation
    if (!customerName || !phone || !cakeId) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = `INSERT INTO orders (customerName, email, address, phone, cakeId, quantity, totalPrice) VALUES (?, ?, ?, ?, ?, ?, ?)`;
    const params = [customerName, email, address, phone, cakeId, quantity, totalPrice];
    
    db.run(sql, params, function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.json({
            message: "Order placed successfully!",
            orderId: this.lastID
        });
    });
});

// Submit feedback
app.post('/api/feedback', (req, res) => {
    const { name, rating, message } = req.body;

    if (!name || !rating || !message) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = `INSERT INTO feedback (name, rating, message) VALUES (?, ?, ?)`;
    db.run(sql, [name, rating, message], function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.json({
            message: "Feedback submitted successfully!",
            feedbackId: this.lastID
        });
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
